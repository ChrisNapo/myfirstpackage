# mypackage
This librery was created as an example of how to publish my own Python package.

## building this package locally
'python setup.py sdist'

##installing this packkage from GitHub
'pip install git+https://github.com/ChrisNapo/myfirstpackage.git'

## updating this package from GitHub
'pip istall --upgrade git+https://github.com/ChrisNapo/myfirstpackage.git'